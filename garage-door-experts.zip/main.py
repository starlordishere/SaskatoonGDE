import os  # Import the os module to access environment variables

from flask import Flask, flash, redirect, render_template, request, url_for
from flask_mail import Mail, Message
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# Configure the SQLite database
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///garage_door_experts.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Email configuration using environment variables
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = os.getenv('Mail_forexperts')
app.config['MAIL_PASSWORD'] = os.getenv('mail_password')
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('Mail_forexperts')  # Use the same Gmail as sender


# Initialize extensions
db = SQLAlchemy(app)
mail = Mail(app)

# Database model
class ContactForm(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    message = db.Column(db.Text, nullable=False)

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/services')
def services():
    return render_template('services.html')


@app.route('/contact', methods=['GET', 'POST'])
def contact():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        message = request.form['message']

        # Save to the database
        new_contact = ContactForm(name=name, email=email, message=message)
        db.session.add(new_contact)
        db.session.commit()

        # Send email to Garage Door Experts
        try:
            msg = Message(
                subject='Need Quote - New Contact Form ',
                recipients=['gdexperts111@gmail.com'],  # Change to your recipient email
                body=f"Name: {name}\nEmail: {email}\nMessage: {message}"
            )
            mail.send(msg)
            flash('Message sent successfully!', 'success')
        except Exception as e:
            flash(f'Error sending email: {e}', 'danger')

        return redirect(url_for('index'))

    return render_template('contact.html')

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Ensure the database tables are created within the app context
    app.run(debug=True)

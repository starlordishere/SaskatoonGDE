// Select DOM elements
const hamburger = document.querySelector('.hamburger');
const navLinks = document.querySelector('.nav-links');
const body = document.querySelector('body');

function toggleMenu() {
        const navLinks = document.querySelector('.nav-links');
        navLinks.classList.toggle('active');
    }



// hero section slide shows 
let slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
    showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
    showSlides(slideIndex = n);
}

function showSlides(n) {
    let i;
    let slides = document.getElementsByClassName("mySlides");
    let dots = document.getElementsByClassName("dot");

    if (n > slides.length) { slideIndex = 1 }
    if (n < 1) { slideIndex = slides.length }

    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }

    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }

    slides[slideIndex - 1].style.display = "block";
    dots[slideIndex - 1].className += " active";
}

// Automatically change slides every 5 seconds
setInterval(() => {
    plusSlides(1);
}, 5000);



function scrollToSection(sectionId) {
    // Remove active class from all hidden details
    const allDetails = document.querySelectorAll('.hidden-details');
    allDetails.forEach(detail => detail.classList.remove('active'));

    // Show the clicked section
    const section = document.getElementById(sectionId);
    section.classList.add('active');

    // Scroll to the clicked section
    section.scrollIntoView({ behavior: 'smooth' });
}

function toggleDetails(sectionId) {
    const detailsSection = document.getElementById(sectionId);
    if (detailsSection.style.display === "block") {
        detailsSection.style.display = "none";
    } else {
        detailsSection.style.display = "block";
    }
}

